// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


// RT Upscaling & Denoising (2 of 2 files)

// Purpose:
	// RT Upscale & Denoising: 

		// When running low res RT or Denoising:
			// the Primary Deferred Pass doesn't add lighting to the scene, it defers it
			// this pass runs. as a last or only denoising / upscaling pass. there is a similiar file for the previous passes, if any
				// this pass samples the defered lighting and applies it
					// because ALL lighting is deferred and then applied here, there will probably be loss of quality in direct lighting vs if it was calculated at full res
						// it would be better to maybe seperate out direct sun lighting since it doesn't have to be RT,
						// but then it wouldn't get denoised here
		
		
	// This could be done a lot better, this is the simplest way to denoise lighting that I could think of


// Our Settings
	#include "/stuff/settings.glsl"

// Data from Minecraft / Iris
    uniform vec3 skyColor;
	uniform vec3 cameraPosition;
	uniform vec3 previousCameraPosition;
	uniform vec3 shadowLightPosition;
	uniform int frameCounter;
	uniform int isEyeInWater;
	uniform vec3 fogColor; //underwater this is the biome's water color
	uniform bool hideGUI;
	uniform ivec2 eyeBrightnessSmooth;
	uniform float viewWidth;
	uniform float viewHeight;
    uniform float frameTimeCounter;
    #define RTV_FRAMETIME_DECLARED 1
	uniform float near;
	uniform float far;

// Samplers / Textures / Images
	
	//depth
	uniform sampler2D  depthtex0;
	
	//working scene image
    uniform sampler2D colortex0; // scene image
	
	//defered data
    uniform sampler2D colortex1; // albedo
    uniform sampler2D colortex2; // specular tex 
    uniform sampler2D colortex3; // normals tex (in world space) 
    uniform sampler2D colortex4; // defered_data_1_tex; // vec4(lmcoord,ao,height_map);
	uniform sampler2D colortex5; // vec4 normals_face_world, float material_mask_id
	#if DENOISING_PASSES > 1
        //we have flaggedif there are multiple passes, so that we can do things differently 
			//if this is the first and only pass, it needs to sample the (low res) trace Data in colortex6
			//if it is a second or third pass, it needs to sample the upscaled data in colortex7, to process it again
			
        uniform sampler2D colortex7; // full res hdr lighting that is already partially upscaled/denoised
		// we are going to use a define trick to load from a different sampler without having to change the code after thos point 
        #define LIGHT_SAMPLER colortex7
		//we likewise change the variable we use for knowing the resolution of the input
        #define ACTIVE_RT_RESOLUTION_DIVIDER 1 
    #else
		//if this is the first pass, it samples the (low res) colortex6, at its given resolution
        #define LIGHT_SAMPLER colortex6
        #define ACTIVE_RT_RESOLUTION_DIVIDER int(RT_RESOLUTION_DIVIDER)
    #endif
	//the 3d texture we are writing voxel data to
	layout (r32ui) uniform uimage3D cimage1;
	//our 3d image with voxel data as an interpolated sampler
	uniform usampler3D cSampler1;

// Data from Vertex Shader
    in vec2 texcoord;
	
// Global variables
	vec3 Sun_or_moon_dir_world;
	vec3 Dither_offset;

// Outputs
	/* RENDERTARGETS:0 */
	layout(location = 0) out vec4 color;

// Included files 
	#include "/stuff/color/srgb_conversion.glsl"
	#include "/stuff/space_transforms.glsl"
	#include "/stuff/shadowmap_sampling.glsl"
	#define UNPACKING_VOXEL_UVS_HERE 1
	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_packing.glsl"
    #include "/stuff/rt/rt.glsl"
    #include "/stuff/voxelizing/emitters.glsl"
    #include "/stuff/noise/noise_texture.glsl"
	#include "/stuff/noise/noise_functions.glsl"
	#include "/stuff/reprojection.glsl"
	#if CLOUD_STYLE == 1
		#include "/stuff/volumetric_clouds.glsl"
	#endif




// Functions
	void progress_dither()
	{
		#if TEMPORAL_ACCUMULATION > 0
			Dither_offset = fract(Dither_offset + random_from_vec2(gl_FragCoord.xy) );
		#endif
	}
	
	vec3 get_screen_dither()
	{	
		#if DITHER_TYPE == 1 || DITHER_TYPE == 3 
			return blue_noise().xyz;
		#endif
		#if DITHER_TYPE == 2
			return vec3(
				random_from_vec2(gl_FragCoord.xy),
				random_from_vec2(gl_FragCoord.xy*(1.238+texcoord)),
				random_from_vec2(gl_FragCoord.xy*(3.1497+texcoord))
				);
		#endif
	}
	
	float linearize_depth(in float d)
	{
		// from gl_FragCoord.z to world measurements
		return 2.0 * near  * far / (far + near - (2.0 * d - 1.0) * (far - near));
	}
	




#if RTV_PHONE == 1 && MOBILE_DEBUG_VIEW == 0
// Phone fix: the voxel images are cleared here by hand, at the end of the frame, after every ray has been traced.
// Iris clears them with glClearTexImage, which GLES / MobileGlues may not do, leaving random or stale voxels
// (and imageAtomicMax can never lower a value). Stale voxels are what bounced rainbow colors around the scene.
// Every pixel clears a few voxels; the next frame's shadow pass then voxelizes into zeroed images.
void rtv_clear_voxel_images()
{
	int per_frame = max(int(viewWidth) * int(viewHeight), 1);
	int pix = int(gl_FragCoord.y) * int(viewWidth) + int(gl_FragCoord.x);

	const int voxel_total = VOXEL_AREA * VOXEL_AREA * VOXEL_AREA;
	for(int i = pix; i < voxel_total; i += per_frame)
	{
		ivec3 p = ivec3(i % VOXEL_AREA, (i / VOXEL_AREA) % VOXEL_AREA, i / (VOXEL_AREA * VOXEL_AREA));
		imageStore(cimage1, p, uvec4(0u));
	}

	#if RT_BLOCK_LIGHT_NEE == 1
		// the emitter grid (one uint per 3x3x3 blocks)
		const int emitter_total = RTV_EMITTER_GRID * RTV_EMITTER_GRID * RTV_EMITTER_GRID;
		for(int i = pix; i < emitter_total; i += per_frame)
		{
			ivec3 p = ivec3(i % RTV_EMITTER_GRID, (i / RTV_EMITTER_GRID) % RTV_EMITTER_GRID, i / (RTV_EMITTER_GRID * RTV_EMITTER_GRID));
			imageStore(c_image_emitters, p, uvec4(0u));
		}
	#endif

	#if VOXEL_LODS >= 1 && RT_API >= 6
		// the LOD bitmask image: one uint covers a 4 x 2 x 4 block of voxels
		const ivec3 lod_dim = ivec3(VOXEL_AREA / 4, VOXEL_AREA / 2, VOXEL_AREA / 4);
		const int lod_total = lod_dim.x * lod_dim.y * lod_dim.z;
		for(int i = pix; i < lod_total; i += per_frame)
		{
			ivec3 p = ivec3(i % lod_dim.x, (i / lod_dim.x) % lod_dim.y, i / (lod_dim.x * lod_dim.y));
			imageStore(c_image_voxel_lod_1, p, uvec4(0u));
		}
	#endif
}
#endif


// ---------------------------------------------------------------------------------------------
// Underwater helpers (used by the underwater block in main())
// ---------------------------------------------------------------------------------------------
float uw_hash13(vec3 p)
{
	p = fract(p * 0.1031);
	p += dot(p, p.zyx + 31.32);
	return fract((p.x + p.y) * p.z);
}

// Sharp, animated caustic network (iterated sine domain warp). Tiles seamlessly in world space.
float uw_caustic_tile(vec2 uv, float t)
{
	vec2 p = mod(uv * 6.28318530718, 6.28318530718) - 250.0;
	vec2 i = p;
	float c = 1.0;
	const float inten = 0.005;
	for (int n = 0; n < 4; n++)
	{
		float tt = t * (1.0 - (3.5 / float(n + 1)));
		i = p + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
		c += 1.0 / length(vec2(p.x / (sin(i.x + tt) / inten), p.y / (cos(i.y + tt) / inten)));
	}
	c /= 4.0;
	c = 1.17 - pow(c, 1.4);
	return clamp(pow(abs(c), 8.0), 0.0, 1.0);
}

// Two layers at different scales / directions so the 4-block tiling is never obvious.
float uw_caustic_pattern(vec2 p, float t)
{
	float a = uw_caustic_tile(p * 0.22, t * 0.5 + 23.0);
	vec2 q = vec2(p.x * 0.8 - p.y * 0.6, p.x * 0.6 + p.y * 0.8);
	float b = uw_caustic_tile(q * 0.15 + 7.3, t * 0.37 + 11.0);
	return clamp(0.65 * a + 0.55 * b, 0.0, 1.0);
}

// Soft, moving light shafts: a pattern in the plane the sunlight is projected through.
float uw_shaft_pattern_at(vec2 s, float t)
{
	float a = sin(s.x * 0.85 + t * 0.30) * sin(s.y * 0.70 - t * 0.26);
	float b = sin((s.x + s.y) * 0.42 + t * 0.18);
	float c = sin(s.x * 1.9 - s.y * 1.3 + t * 0.41);
	return smoothstep(-0.25, 0.85, 0.55 * a + 0.30 * b + 0.15 * c);
}

// Floating plankton / marine snow. Each unit cell along the view ray holds at most one tiny particle;
// the closest approach of the ray to that particle decides how bright the pixel is.
float uw_particles(vec3 origin, vec3 dir, float max_dist, float t)
{
	float acc = 0.0;
	for (int k = 0; k < 8; k++)
	{
		vec3 s = origin + dir * (float(k) + 0.5);
		vec3 cell = floor(s);
		float h = uw_hash13(cell);
		if (h < 0.62) continue; // density: ~38% of the cells hold a particle
		vec3 centre = cell + 0.15 + 0.70 * vec3(h, fract(h * 7.31), fract(h * 13.17));
		centre += 0.10 * vec3(sin(t * 0.40 + h * 20.0), sin(t * 0.33 + h * 31.0), cos(t * 0.37 + h * 17.0));
		vec3 to_p = centre - origin;
		float along = dot(to_p, dir);
		if (along < 0.4 || along > max_dist) continue; // behind the camera / behind the scenery
		float miss = length(to_p - dir * along);
		float radius = max(0.022, 0.0016 * along);
		float twinkle = 0.55 + 0.45 * sin(t * 1.6 + h * 40.0);
		acc += smoothstep(radius, radius * 0.15, miss) * twinkle * exp(-along * 0.16);
	}
	return acc;
}

// Main Function

void main()
{
	#if RTV_PHONE == 1 && MOBILE_DEBUG_VIEW == 0
		rtv_clear_voxel_images(); // (off while the debug panels are on, they read the voxel image in this same pass)
	#endif
	// This is just Copy-Pasted from the Deferred Primary Pass, and poorly pruned
	
	
	// Setup
	
		vec3 Debug_value; //so we can debug locally coped stuff at the end of the function
		
		#if RAYTRACING_VIEW == 1
			//we are ray tracing the right half of the screen, so ignore it here
			if(texcoord.x<=.5)
			{
		#endif
		#if RAYTRACING_VIEW == 2
			//we are ray tracing the entire screen, so ignore it here
			if(false)
			{
		#endif
        
    // Load data and unpack
		float depth_tex_read = texture(depthtex0,texcoord).r;

		vec4 albedo = texture(colortex1, texcoord);
		vec4 specular_tex = texture(colortex2, texcoord);
		//vec4 defered_data_1_tex = texture(colortex4, texcoord);
		//vec2 lmcoord = defered_data_1_tex.xy;
		vec4 deferred_data2 =  texture(colortex5, texcoord);
		vec3 normals_face_world = deferred_data2.xyz;
		float material_mask_id = deferred_data2.a;
		vec3 normals_texture_world = texture(colortex3, texcoord).xyz;

		bool primary_ray_hit = depth_tex_read <1. && abs(material_mask_id-41.) > .5;

		//unpack 
		albedo.rgb = srgb_to_linear(albedo.rgb);
		float sss = specular_tex.b < 64.5? specular_tex.b/64. : 0.;
		
		float emmission = specular_tex.a * BLOCK_LIGHT_BRIGHTNESS; //emission

	// Setup
	
		vec3 view_dir_world;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 direction_screen = vec3(texcoord, 1.);
				vec3 direction_view = screen_to_view_space(direction_screen);
				view_dir_world = normalize( view_to_foot_direction(direction_view) );
			}

		// fix imposible viewing angles from normal textues that point away from the camera
		if( dot(normals_texture_world,view_dir_world) > 0. )  normals_texture_world = normals_face_world;

		#if USE_TEXTURE_NORMALS == 0
			normals_texture_world = normals_face_world;
		#endif
		
		vec3 foot_pos;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 position_screen = vec3(texcoord, depth_tex_read);
				vec3 position_view = screen_to_view_space(position_screen);
				foot_pos = view_to_foot_space(position_view);
			}

		//Load a Dither / Randomness / Offset
		Dither_offset = get_screen_dither();
		//change per frame
		#if TEMPORAL_ACCUMULATION > 0
			#if TEMPORAL_ACCUMULATION == 1
				if(hideGUI) Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#else
				Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#endif
		#endif
			
	// Apply our lighting
	
		//get sun direction in the world
		Sun_or_moon_dir_world = normalize(
				view_to_foot_direction(shadowLightPosition)
				 #if SOFT_RT_SHADOWS == 1 && SHADOWS_USED_ON_SCREEN == 1
					+ SUN_WIDTH * (2.*Dither_offset.xyz-1.)
				#endif
			);
					
		//Load & Upscale Lighting
		vec3 lighting_last = RTV_SAFE3(texture(LIGHT_SAMPLER,texcoord).rgb, 10000.);

		#if RT_DENOISING == 1
			// we will manually blend between neighboring samples
			
			//load samples around this point
			ivec2 uv = ivec2(gl_FragCoord.xy);
			ivec2 depth_size = textureSize(depthtex0, 0);
			ivec2 depth_max_uv = max(depth_size - ivec2(1), ivec2(0));
			ivec2 light_size = textureSize(LIGHT_SAMPLER, 0);
			ivec2 light_max_uv = max(light_size - ivec2(1), ivec2(0));
									
			//weigh thier similarity and blend, according to these rules
			
			//initialize the sample pool
			float total_weight = 0.;
			vec3 sampled_color = vec3(0.);
							
			//loop through neighboring pixels
			for(int x = -RT_DENOISING_KERNEL_SIZE ; x<= RT_DENOISING_KERNEL_SIZE ; x++)
			{
				for(int y = -RT_DENOISING_KERNEL_SIZE ; y<= RT_DENOISING_KERNEL_SIZE ; y++)
				{
					// water: the see-through image (sea floor) must stay sharp, so water pixels only blend with their nearest neighbors
					if (abs(material_mask_id - 1.0) < 0.5 && max(abs(x), abs(y)) > WATER_DENOISE_RADIUS) continue;
					//kernel blur 
					float kblur = max(0.0, 1.0 - KERNEL_FADE * (abs(x) + abs(y)) / float(max(1, RT_DENOISING_KERNEL_SIZE + RT_DENOISING_KERNEL_SIZE)));

                    // Keep each pass locally edge-aware; wide strides leave speckles between taps.
                    ivec2 n_uv = clamp(uv + ivec2(x, y) * max(1, ACTIVE_RT_RESOLUTION_DIVIDER),
                                       ivec2(0), depth_max_uv);
                    ivec2 light_uv = clamp(n_uv / ACTIVE_RT_RESOLUTION_DIVIDER, ivec2(0), light_max_uv);
                    vec3 lighting_sample2 = RTV_SAFE3(texelFetch(LIGHT_SAMPLER, light_uv, 0).rgb, 10000.);
                    vec3 normals2 = texelFetch(colortex3, n_uv, 0).rgb;
                    float depth_tex_read2 = texelFetch(depthtex0, n_uv, 0).r;
                    float neighbor_material_mask_id = texelFetch(colortex5, n_uv, 0).a;
					
					// Keep first-person hand/item samples separate from the world behind them.
					float center_is_hand = step(100.5, abs(material_mask_id));
					float neighbor_is_hand = step(100.5, abs(neighbor_material_mask_id));
					float hand_region_match = 1.0 - abs(center_is_hand - neighbor_is_hand);
                    // Mask 100 is a mob/entity; do not mix its denoising samples with terrain.
                    float center_is_entity = 1.0 - step(0.5, abs(material_mask_id - 100.0));
                    float neighbor_is_entity = 1.0 - step(0.5, abs(neighbor_material_mask_id - 100.0));
                    float entity_region_match = 1.0 - abs(center_is_entity - neighbor_is_entity);

					//compare
					float w = kblur* // kernel blur/fade on edges
						pow( max(0., dot(normals2,normals_texture_world) ),RT_DENOISING_NORMALS_EXP) // normals weight
						* max(0., 1. - abs(linearize_depth(depth_tex_read2)-linearize_depth(depth_tex_read)) / (0.25 + 0.10*linearize_depth(depth_tex_read)) ) // depth weight, relative to distance so slopes and far areas still get denoised
						* hand_region_match
						* entity_region_match
						;
					//add to sample pool
					if (x == 0 && y == 0) w = max(w, 0.0001);
					sampled_color += lighting_sample2 * w;
					total_weight += w;
				}
			}
			
			//normalize the sample
			vec3 lighting = clamp(sampled_color / max(total_weight, 0.001), 0.0, 10000.0);
        #else
            vec3 lighting = lighting_last;
		#endif

        #if DENOISE_REFRACTIONS == 0
            if(albedo.a<.999) lighting.rgb = lighting_last.rgb;
        #endif

		//To apply the lighting we need the tint of the bounced light (albedo for diffuse, white for mirror-like reflection).
		// This MUST be smooth and deterministic: it is applied AFTER denoising and temporal accumulation, so nothing can average it out.
		// (It used to be re-rolled here from a random scattered ray direction, which gave every pixel a different random white tint
		// every frame: the white / pink / blue moving dots on grass.)
		// Rough surfaces (grass, dirt, leaves...) have no fresnel sheen, only smooth ones (water, glass, ice, polished metal) do.
		float tint_smoothness = specular_tex.r * specular_tex.r;
		float fresnel = pow( max(0., dot( view_dir_world, reflect(view_dir_world, normals_texture_world))) ,6.) * tint_smoothness;
		float shininess = specular_tex.g +(1.-specular_tex.g)*fresnel;

		//tinting of bounced light, light is tinted when it diffuses into a surface or bounces off metal 
		vec3 tinting = 
			(specular_tex.g>229.6/255.) ? 
			mix(albedo.rgb, vec3(1.), fresnel) //metals
			:
			mix(albedo.rgb, vec3(1.), shininess); //non-metals
		
		
		//Apply the lighting
		color.rgb  = lighting * tinting
			+ emmission * albedo.rgb * EMISSION_STRENGTH; //shiny things are still allowed to glow. Added after denoising so it cannot bleed into neighbours (EMISSION_STRENGTH 2.0 = same brightness as before, when it was added twice)
		#if RTV_PHONE == 1
			color.rgb = rtv_safe3(color.rgb, 1000000.); //phone: a NaN pixel must never reach the screen
		#endif
			
	
	//Sky & background
	
	if(!primary_ray_hit )
	{
	// Add background
		vec4 bg = texture(colortex0, texcoord) ;
		#if TONEMAPPING > 0
			bg.rgb = srgb_to_linear(bg.rgb) * (SUN_BRIGHTNESS * rtv_sky_illumination_factor());
		#endif

		color.rgb = bg.rgb;

		// Volumetric clouds. They have to be drawn HERE: the deferred pass only writes the ray traced lighting buffers when denoising is on
		// (its 'color' is a throw-away local), so clouds drawn there never reached the screen.
		#if CLOUD_STYLE == 1
		{
			vec3 cloud_sun_dir = normalize(view_to_foot_direction(shadowLightPosition));
			// static blue-noise jitter (no per-frame offset): the sky is not temporally accumulated, so a moving jitter would shimmer
			vec4 cloud = rtv_volumetric_clouds(normalize(view_dir_world), cloud_sun_dir, get_screen_dither().x);
			#if TONEMAPPING > 0
				color.rgb = color.rgb * cloud.a + cloud.rgb * SUN_BRIGHTNESS;
			#else
				color.rgb = color.rgb * cloud.a + linear_to_srgb(clamp(cloud.rgb * 0.62, 0.0, 1.0));
			#endif
		}
		#endif
	}

	// Underwater volume (rewritten):
	//  - fog / scattering is scaled to the scene's HDR range (the old values were ~1/30 of what is needed, so the water looked like air)
	//  - sunlight reaching the sea floor fades with depth (vanilla sky light drops 1 level per water block)
	//  - caustics are multiplied onto the lit surfaces, with a sharp animated network, instead of only into the fog
	//  - volumetric light shafts are ray marched along the view ray
	//  - drifting plankton particles and a soft vignette
	if(isEyeInWater == 1)
	{
		float uw_density = 1.0 / max(UNDERWATER_VISIBILITY, 0.5);
		float uw_dist = primary_ray_hit ? length(foot_pos) : 64.0;
		uw_dist = clamp(uw_dist, 0.0, 160.0);
		float uw_time = frameTimeCounter;
		vec3 uw_view = normalize(view_dir_world);
		float uw_fog = 1.0 - exp(-uw_dist * 0.035 * uw_density * UNDERWATER_FOG_STRENGTH);

		// Water colour: a clear blue-teal base, lightly pulled toward the biome's water colour (swamp = greener, warm ocean = turquoise).
		float uw_biome_max = max(max(fogColor.r, fogColor.g), fogColor.b);
		vec3 uw_hue = uw_biome_max > 0.001 ? fogColor / uw_biome_max : vec3(0.12, 0.62, 1.0);
		vec3 uw_base = vec3(0.06, 0.30, 0.46);
		vec3 uw_color = mix(uw_base, uw_base * (0.62 + 0.38 * uw_hue), 0.30);
		vec3 uw_color_norm = uw_color / max(max(uw_color.r, uw_color.g), uw_color.b);

		// Light available where the player is: dark in caves / at night, bright near the surface in daytime.
		float uw_sky = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
		float uw_light = mix(0.03, 1.0, uw_sky * uw_sky);
		float uw_scale = SUN_BRIGHTNESS * rtv_sky_illumination_factor(); // HDR scale of the scene

		// Beer-Lambert absorption: red goes first, blue last.
		// Same coefficients as the water seen from above (deferred pass), so the sea floor has the same colour whether you look at it
		// through the surface or from inside the water. (It used to be half as strong, which made the inside look flat and clear.)
		vec3 uw_absorb = exp(-vec3(0.120, 0.045, 0.022) * WATER_ABSORPTION * uw_density * uw_dist);

		// ---- surfaces: depth dimming + caustics ----
		vec2 uw_lm = texture(colortex4, texcoord).xy;
		bool uw_world_hit = primary_ray_hit && material_mask_id < 100.5 && abs(material_mask_id - 1.0) > 0.5;
		if(uw_world_hit)
		{
			// Direct sun is shadow-mapped, so without this a sea floor 20 blocks down is as bright as dry land.
			color.rgb *= mix(0.30, 1.0, smoothstep(0.15, 0.95, uw_lm.y));

			vec3 uw_world_pos = foot_pos + cameraPosition;
			vec3 uw_abs_normal = abs(normals_face_world);
			vec2 caustic_p;
			if(uw_abs_normal.y >= uw_abs_normal.x && uw_abs_normal.y >= uw_abs_normal.z)
				caustic_p = uw_world_pos.xz;
			else if(uw_abs_normal.x >= uw_abs_normal.z)
				caustic_p = uw_world_pos.zy;
			else
				caustic_p = uw_world_pos.xy;

			float caustic_pattern = uw_caustic_pattern(caustic_p, uw_time);
			float upward_surface = clamp(normals_face_world.y, 0.0, 1.0);
			float caustic_surface_mask = mix(0.15, 1.0, smoothstep(0.05, 0.82, upward_surface));
			float caustic_depth_fade = exp(-uw_dist * 0.020 * uw_density);
			float caustic_sky_gate = smoothstep(0.40, 0.90, uw_lm.y) * rtv_sunlight_factor();
			float caustic_amount = caustic_pattern * caustic_surface_mask * caustic_depth_fade * caustic_sky_gate * UNDERWATER_CAUSTICS_STRENGTH;
			// brighter lines on the surface, slightly cyan-white like real caustics
			color.rgb *= 1.0 + 1.9 * caustic_amount * vec3(0.90, 1.00, 1.06);
		}

		// ---- scattering fog ----
		// Scattered light is NOT the same in every direction: looking up you see bright cyan light filtering down from the surface,
		// looking down you see dark, deep, blue-shifted water. This vertical gradient is what gives the volume its depth.
		float uw_up = smoothstep(0.10, 0.95, uw_view.y * 0.5 + 0.5);
		vec3 uw_scatter_deep = uw_color * vec3(0.55, 0.75, 1.00) * 0.10;
		vec3 uw_scatter_up = uw_color_norm * vec3(0.55, 0.95, 1.00) * 0.46;
		vec3 uw_scatter = mix(uw_scatter_deep, uw_scatter_up, uw_up) * uw_scale * uw_light;
		// a soft glow around the direction of the sun
		uw_scatter += uw_color_norm * rtv_sun_color() * uw_scale * rtv_sunlight_factor() * uw_light
			* (0.10 * pow(max(dot(uw_view, Sun_or_moon_dir_world), 0.0), 3.0));

		// ---- ray marched light shafts ----
		vec3 uw_god_rays = vec3(0.0);
		if(UNDERWATER_RAYS_STRENGTH > 0.0)
		{
			float uw_view_to_sun = max(dot(uw_view, Sun_or_moon_dir_world), 0.0);
			float uw_phase = 0.20 + 0.80 * pow(uw_view_to_sun, 6.0);
			float uw_march = min(uw_dist, 48.0);
			vec2 uw_sun_slope = Sun_or_moon_dir_world.xz / max(abs(Sun_or_moon_dir_world.y), 0.25);
			float uw_shaft_sum = 0.0;
			const int UW_SHAFT_STEPS = 10;
			for(int i = 0; i < UW_SHAFT_STEPS; i++)
			{
				float st = (float(i) + Dither_offset.x) / float(UW_SHAFT_STEPS) * uw_march;
				vec3 sp = cameraPosition + uw_view * st;
				vec2 sproj = sp.xz - uw_sun_slope * sp.y; // slide the sample up the sun direction to the water surface
				uw_shaft_sum += uw_shaft_pattern_at(sproj, uw_time) * exp(-st * 0.030);
			}
			uw_shaft_sum /= float(UW_SHAFT_STEPS);
			uw_shaft_sum *= 1.0 - exp(-uw_march * 0.060);
			uw_god_rays = mix(vec3(1.0), uw_color_norm, 0.55) * rtv_sun_color()
				* (uw_scale * rtv_sunlight_factor() * 0.55 * uw_light * uw_shaft_sum * uw_phase * UNDERWATER_RAYS_STRENGTH);
		}

		// ---- plankton / marine snow ----
		vec3 uw_plankton = vec3(0.0);
		if(UNDERWATER_PARTICLES > 0.0)
		{
			float uw_p = uw_particles(cameraPosition, uw_view, primary_ray_hit ? length(foot_pos) : 12.0, uw_time);
			uw_plankton = mix(vec3(0.85, 1.0, 1.0), uw_color_norm, 0.35) * (uw_p * uw_scale * 0.16 * (0.25 + 0.75 * uw_light) * UNDERWATER_PARTICLES);
		}

		vec3 uw_transmitted = color.rgb * uw_absorb;
		vec3 uw_hue_filter = mix(vec3(1.0), uw_color_norm, 0.18 * uw_fog);
		color.rgb = uw_transmitted * uw_hue_filter
			+ uw_scatter * uw_fog + uw_god_rays + uw_plankton;

		// Soft lens vignette: darker, bluer corners add depth.
		vec2 uw_screen = (texcoord - 0.5) * vec2(viewWidth / max(viewHeight, 1.0), 1.0);
		float uw_edge = smoothstep(0.30, 1.05, length(uw_screen));
		float uw_vig = uw_edge * 0.14 * UNDERWATER_VIGNETTE * (0.5 + 0.5 * uw_fog);
		color.rgb = mix(color.rgb, color.rgb * uw_color_norm * 0.80, uw_vig * 1.5) * (1.0 - uw_vig * 0.5);
	}

		#if TONEMAPPING == 1
		#if EXPOSURE == 0
			const float eyeBrightnessHalflife = 30.0;
			float exposure = mix(20.0, 32.0, clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0));
		#else
			float exposure = float(EXPOSURE);
		#endif
		float luminance = (color.r+ color.g+ color.b)/3.;
		color.rgb = color.rgb/(luminance+exposure);
		//screen gamma
		color.rgb = linear_to_srgb(color.rgb);
		color.rgb = rtv_color_grade(color.rgb);
	#endif
	
	
	#if RAYTRACING_VIEW > 0
        }//> close scope of where we ignore part of the screen that are going to be full RT view
//		else{
//			color=vec4(0.);//just write black here if you want to write something, it might become garbage data if you don't, I don't know
//		}
	#endif
	
	
	//Phone debug panels (Advanced > Phone Debug Panels). Three small squares in the top-left corner show which stage of the pipeline works:
	//  1 shadow map   : the sun's depth map. A solid white or solid black square means the shadow pass drew nothing.
	//  2 voxel slice  : the voxel scene around the player, seen from above at foot level. White = solid voxel, red dot = you.
	//                   All dark means nothing was voxelized; random noise means the voxel image holds garbage.
	//  3 light buffer : the ray traced light. Magenta pixels are NaN / Inf / out of range values.
	#if MOBILE_DEBUG_VIEW == 1
	{
		float dbg_size = 0.22;
		float dbg_gap = 0.02;
		vec2 dbg_p = vec2(texcoord.x * viewWidth / viewHeight, 1.0 - texcoord.y);
		for (int dbg_i = 0; dbg_i < 3; dbg_i++)
		{
			vec2 dbg_origin = vec2(dbg_gap + float(dbg_i) * (dbg_size + dbg_gap), dbg_gap);
			vec2 dbg_uv = (dbg_p - dbg_origin) / dbg_size;
			if (dbg_uv.x >= 0.0 && dbg_uv.x <= 1.0 && dbg_uv.y >= 0.0 && dbg_uv.y <= 1.0)
			{
				vec3 dbg_color = vec3(0.0);
				if (dbg_i == 0)
				{
					dbg_color = vec3(texture(shadowtex1, vec2(dbg_uv.x, 1.0 - dbg_uv.y)).r);
				}
				if (dbg_i == 1)
				{
					ivec3 dbg_voxel = ivec3(clamp(int(dbg_uv.x * float(VOXEL_AREA)), 0, VOXEL_AREA - 1), VOXEL_AREA / 2 - 1, clamp(int(dbg_uv.y * float(VOXEL_AREA)), 0, VOXEL_AREA - 1));
					uint dbg_data = imageLoad(cimage1, dbg_voxel).r;
					dbg_color = dbg_data != 0u ? vec3(1.0) : vec3(0.0, 0.0, 0.2);
					if (length(dbg_uv - vec2(0.5)) < 0.02) dbg_color = vec3(1.0, 0.0, 0.0);
				}
				if (dbg_i == 2)
				{
					vec3 dbg_light = texture(LIGHT_SAMPLER, vec2(dbg_uv.x, 1.0 - dbg_uv.y)).rgb;
					bool dbg_ok = dbg_light.r >= 0.0 && dbg_light.r <= 100000.0 && dbg_light.g >= 0.0 && dbg_light.g <= 100000.0 && dbg_light.b >= 0.0 && dbg_light.b <= 100000.0;
					dbg_color = dbg_ok ? clamp(dbg_light * 0.02, 0.0, 1.0) : vec3(1.0, 0.0, 1.0);
				}
				float dbg_edge = min(min(dbg_uv.x, dbg_uv.y), min(1.0 - dbg_uv.x, 1.0 - dbg_uv.y));
				color.rgb = dbg_edge < 0.012 ? vec3(1.0, 1.0, 0.0) : dbg_color;
			}
		}
	}
	#endif

	//Debug Area
		//color.rgb = fract(view_dir_world.rgb*10.);
		//color.rgb = fract(foot_pos+cameraPosition);
		//color.rgb = normals_face_world;
		//color.rgb = Dither_offset;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read) ) );
		//color.rgb = .5+.5*normals_texture_world;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read)/far ) );
	
}


