// Emitter grid: one compact 3D image that remembers, for every 3 x 3 x 3 block cell, the brightest light block or
// explicitly mapped glowing item inside it. It is written by the shadow pass together with the voxel scene.
//   bits 0-5: local xyz position; bits 6-20: optional item RGB; bit 21: item-colour flag;
//   bits 28-31: light level. Block emitters keep their colour in the voxel scene.
// Dropped glowing items carry a compact source-colour override while brightness stays the priority key.
#ifndef RTV_EMITTERS_INCLUDED
#define RTV_EMITTERS_INCLUDED 1
#if RT_BLOCK_LIGHT_NEE == 1
    layout (r32ui) uniform uimage3D c_image_emitters;
    #define RTV_EMITTER_CELL 3
    #define RTV_EMITTER_GRID ((VOXEL_AREA + RTV_EMITTER_CELL - 1) / RTV_EMITTER_CELL)

    // Iris item.properties IDs used by RTV for luminous items. These are intentionally
    // pack-local IDs and do not collide with Minecraft's registry IDs.
    #define RTV_ITEM_TORCH             60001
    #define RTV_ITEM_LANTERN           60002
    #define RTV_ITEM_GLOWSTONE         60003
    #define RTV_ITEM_SHROOMLIGHT       60004
    #define RTV_ITEM_CAMPFIRE          60005
    #define RTV_ITEM_SOUL_TORCH        60006
    #define RTV_ITEM_SOUL_LANTERN      60007
    #define RTV_ITEM_REDSTONE_TORCH    60008
    #define RTV_ITEM_SEA_LANTERN       60009
    #define RTV_ITEM_END_ROD           60010
    #define RTV_ITEM_OCHRE_FROGLIGHT   60011
    #define RTV_ITEM_VERDANT_FROGLIGHT 60012
    #define RTV_ITEM_PEARL_FROGLIGHT   60013

    int rtv_dropped_item_light_level(in int item_id)
    {
        if (item_id == RTV_ITEM_TORCH) return 14;
        if (item_id == RTV_ITEM_LANTERN) return 15;
        if (item_id == RTV_ITEM_GLOWSTONE) return 15;
        if (item_id == RTV_ITEM_SHROOMLIGHT) return 15;
        if (item_id == RTV_ITEM_CAMPFIRE) return 15;
        if (item_id == RTV_ITEM_SOUL_TORCH) return 10;
        if (item_id == RTV_ITEM_SOUL_LANTERN) return 10;
        if (item_id == RTV_ITEM_REDSTONE_TORCH) return 7;
        if (item_id == RTV_ITEM_SEA_LANTERN) return 15;
        if (item_id == RTV_ITEM_END_ROD) return 14;
        if (item_id == RTV_ITEM_OCHRE_FROGLIGHT) return 15;
        if (item_id == RTV_ITEM_VERDANT_FROGLIGHT) return 15;
        if (item_id == RTV_ITEM_PEARL_FROGLIGHT) return 15;
        return 0;
    }

    vec3 rtv_item_light_color(in int item_id)
    {
        if (item_id == RTV_ITEM_TORCH) return vec3(1.00, 0.76, 0.48);
        if (item_id == RTV_ITEM_LANTERN) return vec3(1.00, 0.68, 0.39);
        if (item_id == RTV_ITEM_GLOWSTONE) return vec3(1.00, 0.82, 0.55);
        if (item_id == RTV_ITEM_SHROOMLIGHT) return vec3(1.00, 0.46, 0.22);
        if (item_id == RTV_ITEM_CAMPFIRE) return vec3(1.00, 0.40, 0.13);
        if (item_id == RTV_ITEM_SOUL_TORCH) return vec3(0.18, 0.48, 1.00);
        if (item_id == RTV_ITEM_SOUL_LANTERN) return vec3(0.28, 0.60, 1.00);
        if (item_id == RTV_ITEM_REDSTONE_TORCH) return vec3(1.00, 0.035, 0.020);
        if (item_id == RTV_ITEM_SEA_LANTERN) return vec3(0.48, 0.80, 1.00);
        if (item_id == RTV_ITEM_END_ROD) return vec3(0.82, 0.88, 1.00);
        if (item_id == RTV_ITEM_OCHRE_FROGLIGHT) return vec3(1.00, 0.74, 0.32);
        if (item_id == RTV_ITEM_VERDANT_FROGLIGHT) return vec3(0.38, 1.00, 0.30);
        if (item_id == RTV_ITEM_PEARL_FROGLIGHT) return vec3(0.76, 0.50, 1.00);
        return vec3(0.0);
    }

    // The voxel volume moves with the camera (it is re-centred every time you cross a block border). If the 3x3x3 cells moved with it,
    // the single emitter stored per cell would change whenever you walked, and lights would pop on and off. This shift keeps the cell
    // borders locked to the world (multiples of 3 blocks), so the same emitter always wins in the same cell.
    // Cells are addressed with (voxel + shift) / 3, so the same emitters stay stable as the camera moves.
    ivec3 rtv_emitter_shift()
    {
        return ivec3(mod(floor(cameraPosition), vec3(float(RTV_EMITTER_CELL))));
    }
#endif
#endif
