// Randomness and Noise - Functions
   
	//These functions come from an internet search and are just commonly used functions, author unknown
	float random_from_float(float n)
	{
		return fract(sin(n) * 43758.5453123);
	}

	float random_from_vec2(vec2 n)
	{ 
	    return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
    }
	    
	float noise_from_vec2(vec2 n)
	{
	    const vec2 d = vec2(0.0, 1.0);
		vec2 b = floor(n), f = smoothstep(vec2(0.0), vec2(1.0), fract(n));
	    return mix(mix(random_from_vec2(b), random_from_vec2(b + d.yx), f.x), mix(random_from_vec2(b + d.xy), random_from_vec2(b + d.yy), f.x), f.y);
    }