/*---------------------------------------------------------------------
    Unbound water waves (port ke RTV)
    ------------------------------------------------------------------
    Diport dari Unbound: lib/materials/materialMethods/causticWaterWaves.glsl
    Medan tinggi permukaan = ombak lebar (swell) + caustic + sinus berlapis.
    Normal = gradien medan itu (selisih terhingga), sama seperti di Unbound.
    Butuh tekstur water_wave_tex (cloud-water.png, di-load lewat
    customTexture di shaders.properties), setara gaux4 di Unbound.
---------------------------------------------------------------------*/

#ifndef UNBOUND_WATER_WAVES_GLSL
#define UNBOUND_WATER_WAVES_GLSL

uniform sampler2D water_wave_tex;

// WATER_WAVE_SPEED RTV (default 0.70) -> WATER_SPEED_MULT Unbound (default 0.82)
#define UWW_SPEED (WATER_WAVE_SPEED * 1.171)
// Selisih tekstur memakai jarak 2 texel (tekstur 256x256), bukan 0.001 UV seperti di Unbound.
// Jarak sangat kecil itu membuat medan "bertangga" per texel -> terlihat sebagai pola kotak/grid
// begitu dipantulkan ray tracing. Jarak 2 texel jauh lebih halus; skalanya dikompensasi.
#define UWW_TEXEL_OFF (2.0 / 256.0)
#define UWW_DIFF_SCALE (0.001 / UWW_TEXEL_OFF)
// WATER_SINE_WAVE 60 * 0.002 di Unbound
#define UWW_SINE_MIX 0.12

// Caustic: skalar yang sama dengan caustic bawah air Unbound.
float uww_caustic_field(vec2 xz, float time)
{
    float speed = UWW_SPEED * 0.035;
    vec2 wind = vec2(0.0, time * speed);
    vec2 p1 = xz * 0.08 + wind;
    vec2 p2 = xz * 0.06 - wind;
    const float c_mult = 14.0;
    const float off = UWW_TEXEL_OFF;

    float c = dot(textureLod(water_wave_tex, p1 + vec2(off, 0.0), 0.0).rg, vec2(c_mult))
            - dot(textureLod(water_wave_tex, p1 - vec2(off, 0.0), 0.0).rg, vec2(c_mult));
    c      += dot(textureLod(water_wave_tex, p2 + vec2(0.0, off), 0.0).rg, vec2(c_mult))
            - dot(textureLod(water_wave_tex, p2 - vec2(0.0, off), 0.0).rg, vec2(c_mult));
    return c * UWW_DIFF_SCALE;
}

// Sinus berlapis (dari "Simple Water Waves" by yinkar, shadertoy sd2GWR, seperti di Unbound).
float uww_sine_field(vec2 xz, float time)
{
    float k = UWW_SPEED * 0.10;
    float h = 0.0;
    float w = 0.0;
    for (int i = 0; i < 6; i++)
    {
        float fi = float(i);
        float freq = 1.57 / (1.0 + fi * 0.1);
        float spd  = 18.0 - fi * 3.0;
        float amp  = 1.0 / (1.0 + fi * 0.55);
        float dir  = mod(fi, 2.0) * 2.0 - 1.0;
        float ph   = fi * 1.618;
        h += amp * sin(xz.x * freq - time * spd * k + ph)
           + 0.7 * amp * dir * sin(dot(xz, vec2(-0.55, 0.84)) * freq * 1.3 + time * spd * k * 0.8 + ph);
        w += amp;
    }
    return h / max(w, 1e-4);
}

// Ombak lebar + detail caustic + sinus.
float uww_swell_field(vec2 xz, float time)
{
    float speed = UWW_SPEED * 0.022;
    vec2 wind = vec2(time * speed * 0.6, time * speed);
    vec2 p1 = xz * 0.022 + wind;
    vec2 p2 = xz * 0.015 + vec2(-wind.y * 0.7, wind.x * 0.9) + vec2(0.37, 0.61);
    const float c_mult = 14.0;
    const float off = UWW_TEXEL_OFF;

    float s = dot(textureLod(water_wave_tex, p1 + vec2(off, 0.0), 0.0).rg, vec2(c_mult))
            - dot(textureLod(water_wave_tex, p1 - vec2(off, 0.0), 0.0).rg, vec2(c_mult));
    s      += dot(textureLod(water_wave_tex, p2 + vec2(0.0, off), 0.0).rg, vec2(c_mult))
            - dot(textureLod(water_wave_tex, p2 - vec2(0.0, off), 0.0).rg, vec2(c_mult));
    s *= UWW_DIFF_SCALE;

    return s + 0.15 * uww_caustic_field(xz, time) + UWW_SINE_MIX * uww_sine_field(xz, time);
}

// Kemiringan permukaan (dh/dx, dh/dz) dalam ruang dunia, skala identik dengan
// "derivative" di Unbound (CausticWaterNormalTangentSpace).
vec2 uww_water_slope(vec2 world_xz, float time)
{
    const float eps = 0.75;
    float h  = uww_swell_field(world_xz, time);
    float hx = uww_swell_field(world_xz + vec2(eps, 0.0), time);
    float hz = uww_swell_field(world_xz + vec2(0.0, eps), time);

    vec2 grad = vec2(hx - h, hz - h) / eps;
    grad *= 2.6 * 1.2; // 1.2 = kompensasi kemiringan yang jadi lebih landai setelah dihaluskan
    grad /= 1.0 + 0.25 * length(grad);
    return grad * 0.35;
}

#endif
