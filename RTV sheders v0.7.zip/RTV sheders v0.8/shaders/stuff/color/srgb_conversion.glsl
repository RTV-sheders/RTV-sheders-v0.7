//< provided by belmu on shaderlabs discord

	// https://www.titanwolf.org/Network/q/bb468365-7407-4d26-8441-730aaf8582b5/x
	vec3 linearToSrgb(vec3 linear) {
		vec3 higher = (pow(abs(linear), vec3(1.0 / 2.4)) * 1.055) - 0.055;
		vec3 lower  = linear * 12.92;
		return mix(higher, lower, step(linear, vec3(0.0031308)));
	}

	vec3 srgbToLinear(vec3 sRGB) {
		vec3 higher = pow((sRGB + 0.055) / 1.055, vec3(2.4));
		vec3 lower  = sRGB / 12.92;
		return mix(higher, lower, step(sRGB, vec3(0.04045)));
	}

//>


//Fast approximations toggle
	
	#define SRGB_GAMMA 2.2 //[2.0 2.1 2.2 2.3 2.4]
	#define GAMMA_PHYSICAL_DISPLAY 2.2 //[2.0 2.1 2.2 2.3 2.4]
	#define GAMMA_FAST 1 //[0 1]

	vec3 srgb_to_linear(vec3 sRGB)
	{
		#if GAMMA_FAST == 1
			return pow(sRGB, vec3(SRGB_GAMMA));
		#else
			vec3 higher = pow((sRGB + 0.055) / 1.055, vec3(2.4));
			vec3 lower  = sRGB / 12.92;
			return mix(higher, lower, step(sRGB, vec3(0.04045)));
		#endif
	}
	
	vec3 linear_to_srgb(vec3 linear)
	{
		#if GAMMA_FAST == 1
			return pow(linear, vec3(1./GAMMA_PHYSICAL_DISPLAY));
		#else
			vec3 higher = (pow(abs(linear), vec3(1.0 / 2.4)) * 1.055) - 0.055;
			vec3 lower  = linear * 12.92;
			return mix(higher, lower, step(linear, vec3(0.0031308)));
		#endif
	}
